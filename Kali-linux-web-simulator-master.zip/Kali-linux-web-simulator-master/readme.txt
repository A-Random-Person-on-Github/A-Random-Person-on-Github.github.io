this is just a simulator kali linux project 
Code in html css && javascript
In this website you can change background by clicking on Background app
and you can type some basic linux commands to know what they do
you can type common commands to see list of some common commands 
type exit or quit,q for exit the terminal 

 